import java.util.Scanner;

class MinimumAmountException extends Exception {
    MinimumAmountException(String message) {
        super(message);
    }
}

class OnlineShopping {
    void placeOrder(int amount) throws MinimumAmountException {
        if (amount < 500)
            throw new MinimumAmountException("Minimum cart value must be ₹500");

        System.out.println("Order placed successfully");
    }
}

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter cart amount: ");
        int amount = sc.nextInt();

        OnlineShopping o = new OnlineShopping();

        try {
            o.placeOrder(amount);
        } catch (MinimumAmountException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}